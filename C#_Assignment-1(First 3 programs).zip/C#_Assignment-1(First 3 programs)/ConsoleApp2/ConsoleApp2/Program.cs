﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            strmanip();
            Console.ReadLine();
        }

        static void strmanip()
        {

          //(Sub String, Extract first 5 left characters, Extract first five right characters, Extract middle characters from 5 to 10 position)

            Console.WriteLine("STRING MANIPULATION");
            Console.WriteLine("1.Substring Manipulation");
            Console.WriteLine("2.Extract First 5 Left Characters");
            Console.WriteLine("3.Extract First 5 right Characters");
            Console.WriteLine("4.Extract Middle Characters");
            Console.WriteLine("5.Replace given string");
            Console.WriteLine("6.Reverse a given string");

            Console.WriteLine("7.Exit");

            Console.WriteLine("Enter your Choice");
            string choice = Console.ReadLine();
            string enteredText;
            switch(choice) {
                case "1":
                    Console.WriteLine("SubsString Manipulation");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Enter the Text you want to perform string manipulation");
                    enteredText = Console.ReadLine();
                    getSubstring(enteredText);
                    break;
                case "2":
                    Console.WriteLine("Extracting First 5 left Characters from String");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Enter the Text you want to perform string manipulation");
                    enteredText = Console.ReadLine();
                    getFiveLeft(enteredText);
                    break;
                case "3":
                    Console.WriteLine("Extracting First 5 right Characters from String");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Enter the Text you want to perform string manipulation");
                    enteredText = Console.ReadLine();
                    getFiveRight(enteredText);
                    break;
                case "4":
                    Console.WriteLine("Extracting Middle characters");
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Enter the Text you want to perform string manipulation");
                    enteredText = Console.ReadLine();
                    getMiddleCharacters(enteredText);
                    break;
                case "5":
                    Console.WriteLine("Replace the given file");
                    Console.WriteLine("Enter the Text you want to perform string manipulation");
                    enteredText = Console.ReadLine();
                    Console.WriteLine("Find the text you want to replace");
                    string replaceString = Console.ReadLine();
                    Console.WriteLine("Enter the Text you want to replace with");
                    string replaceStringWith = Console.ReadLine();
                    string replacedString = enteredText.Replace(replaceString, replaceStringWith);
                    Console.WriteLine("Edited String \n " + replacedString);
                    break;
                case "6":
                    Console.WriteLine("Reverse a the given String");
                    Console.WriteLine("Enter the Text you want to perform string manipulation");
                    enteredText = Console.ReadLine();

                    char[] stringArray = enteredText.ToCharArray();
                    string reverse = String.Empty;
                    for (int i = stringArray.Length - 1; i >= 0; i--)
                    {
                        reverse += stringArray[i];
                    }
                    Console.WriteLine(reverse);


                    break;


                case "7":
                    Console.WriteLine("Exiting Wait for 5 Seconds");
                    System.Threading.Thread.Sleep(5000);
                    Console.Clear();
                    strmanip();
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("You entered the wrong choice. Try Again");
                    strmanip();
                    break;

            }

           // Console.WriteLine(choice);
        }

        static void getSubstring(string text)
        {
            Console.WriteLine(" wow " +text);
            string authorName = text.Substring(0, 5);
            Console.WriteLine("You First name after String Manipulation");
            Console.WriteLine(authorName);
        }
        static void getFiveLeft(string text)
        {
            Console.WriteLine(" wow " + text);
            char[] array = text.Take(5).ToArray();
            Console.WriteLine("You Left Five Characters are ");
            Console.WriteLine(array);

        }
        static void getFiveRight(string text)
        {
            Console.WriteLine(" wow " + text);
            text.Substring(Math.Max(0, text.Length - 4));
            Console.WriteLine("You Right Five Characters are ");
            Console.WriteLine(text.Substring(Math.Max(0, text.Length - 5)));
        }
        static void getMiddleCharacters(string text)
        {
            var lengthOfString = text.Length / 2;
            string authorName = text.Substring(lengthOfString, 1);
            Console.WriteLine(authorName);
        }






    }
}
