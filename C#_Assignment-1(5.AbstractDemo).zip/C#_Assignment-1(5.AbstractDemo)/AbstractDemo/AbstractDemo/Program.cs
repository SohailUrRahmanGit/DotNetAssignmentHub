﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo
{
    abstract class Cluster
    {
        public virtual void Set()
        {

        }
    }
    class AbsDemo : Cluster
    {
        protected int ClusterID;
        protected string ClusterName;

        public void SetClusterTraining(int cID, string cName)
        {
            ClusterID = cID;
            ClusterName = cName;
        }

        public String GetTutorial()
        {
            return ClusterName;
        }

        static void Main(string[] args)
        {
            AbsDemo cTutor = new AbsDemo();

            cTutor.SetClusterTraining(1, "Cluster c#");

            Console.WriteLine(cTutor.GetTutorial());

            Console.ReadKey();
        }
    }
}
