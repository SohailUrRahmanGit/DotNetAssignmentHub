﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    interface myInterface
    {
        void diplayName(string somestring);
        void diplayAge(string somestring);
        void diplayPhoneNo(string somestring);
    }


    class Program : myInterface
    {



        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Program one = new Program();

            one.diplayName("Sohail");
            one.diplayAge("30");
            one.diplayPhoneNo("123456");


            AnotherClass two = new AnotherClass();
           
            two.diplayAge("15");
            two.diplayName("Rahnman");
            two.diplayPhoneNo("65498741");
        }


      


        public void diplayAge(string somestring)
        {
            Console.WriteLine("my age is" + somestring);
        }

        public void diplayName(string somestring)
        {
            Console.WriteLine("My name is " + somestring);
        }

        public void diplayPhoneNo(string somestring)
        {
            Console.WriteLine("My contact no is " + somestring);
        }

    }

    class AnotherClass : myInterface
    {
        public string name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;

            }

        }

        public void diplayAge(string somestring)
        {
            Console.WriteLine("my age is" + somestring);
        }

        public void diplayName(string somestring)
        {
            Console.WriteLine("My name is " + somestring);
        }

        public void diplayPhoneNo(string somestring)
        {
            Console.WriteLine("My contact no is " + somestring);
        }

    }


}
