﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceExample
{
    public class User
    {
        public string Name;
        private string Location;

        public User()
        {
            Console.WriteLine("BaseConstructor");
        }
        public void GetUserInfo(string loc)
        {
            Location = loc;
            Console.WriteLine("Name: {0}", Name);
            Console.WriteLine("Location: {0}", Location);
        }
    }

    public class Details : User
    {
        public int Age;
        public Details()
        {
            Console.WriteLine("ChildConstructor");
        }
        public void GetAge()
        {
            Console.WriteLine("Age: {0}", Age);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Details d = new Details();
            d.Name = "Sohail ur rahman";       
            d.Age = 32;
            d.GetUserInfo("Chennai");
            d.GetAge();
           

        }

    }
}
