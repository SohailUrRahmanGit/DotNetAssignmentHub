﻿using System;
using System.Text;

namespace StringBuilderConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder firstName = new StringBuilder("Sohail");
            Console.WriteLine(firstName);
            firstName.Append(", Ur Rahman");
            Console.WriteLine(firstName);


            StringBuilder sb1 = new StringBuilder("Inserting example ");
            sb1.Insert(8, "here ");

            Console.WriteLine("Insert String: " + sb1);



            StringBuilder sb2 = new StringBuilder("Removing Example here");

            sb2.Remove(8, 3);

            Console.WriteLine(sb2);



        }
    }
}
