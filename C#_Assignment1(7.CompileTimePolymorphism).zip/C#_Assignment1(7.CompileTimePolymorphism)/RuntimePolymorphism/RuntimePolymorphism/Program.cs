﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RuntimePolymorphism
{
    public class BaseClass
    {
        public virtual void GetInfo()
        {
            Console.WriteLine("Learn C# Tutorial");
        }
    }
    public class DerivedClass : BaseClass
    {
        public override void GetInfo()
        {
         Console.WriteLine("Welcome to Xamarin");
        }
     }

    class Program
    {
        static void Main(string[] args)
        {
            DerivedClass d = new DerivedClass();
            d.GetInfo();
            BaseClass b = new BaseClass();
            b.GetInfo();
            
         }
    }

}

