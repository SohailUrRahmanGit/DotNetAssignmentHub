﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo
{
    class User
    {
        public string name, location;
        // Default Constructor
        public User()
        {
            name = "SOHAIL UR RAHMAN";
            location = "chennai";
        }
   }
    class Program
    {
        static void Main(string[] args)
        {
            User user = new User();
            Console.WriteLine(user.name);
            Console.WriteLine(user.location);
            Console.WriteLine("\nPress Enter Key to Exit..");
            Console.ReadLine();
        }
    }
}
