﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SETGETDEMO
{
    class User
    {
        private string location;
        private string name = "SOHAIL";
        public string Location
        {
            get { return location; }
            set { location = value; }
        }
        public string Name
        {
            get
            {
               return name.ToUpper();
            }
            set
            {
                if (value != "SOHAIL ")
                    name = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            User u = new User();
            u.Name = "Rahman";
            u.Location = "Chennai";
            Console.WriteLine("Name: " + u.Name);
            Console.WriteLine("Location: " + u.Location);

            if(u.Name == "Rahman")
            {
                Console.WriteLine("Name: " + u.Name);
            }
            else if (u.Name == "Shaik")
            {
                Console.WriteLine("Name Not yet Set");
            }
            else
            {
                Console.WriteLine("Name is John Doe");
            }

            switch(u.Location)
            {
                case "Chennai":
                        break;
                case "Hyderabad":
                    break;
                        default:
                    break;

            }

            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("Name: " + u.Name);
            }



        }
    }
}
